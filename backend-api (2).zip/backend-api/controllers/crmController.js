const { User, Appointment, EmergencyResponse, BloodRequest, Interaction } = require('../models');
const ACCOUNT_TYPES = require('../utils/accountTypes');
const calculateDonationEligibility = require('../utils/donationEligibility');

const inactiveAfterDays = 180;
const followUpGapInDays = 14;
const millisecondsPerDay = 1000 * 60 * 60 * 24;
const allowedInteractionTypes = ['call', 'message', 'visit', 'other'];

function daysSince(date) {
  return Math.floor((Date.now() - new Date(date).getTime()) / millisecondsPerDay);
}

async function loadSocietyOrReject(req, res) {
  const user = await User.findByPk(req.userId);
  if (!user || user.accountType !== ACCOUNT_TYPES.SOCIETY) {
    res.status(403).json({ error: 'Only society accounts can use the CRM.' });
    return null;
  }
  return user;
}

async function findDonorIdsForSociety(societyId) {
  const attachedDonors = await User.findAll({
    where: { accountType: ACCOUNT_TYPES.DONOR, attachedSocietyId: societyId },
    attributes: ['id']
  });
  const bookedAppointments = await Appointment.findAll({
    where: { societyId },
    attributes: ['donorId']
  });

  const donorIds = new Set();
  attachedDonors.forEach(function (donor) { donorIds.add(donor.id); });
  bookedAppointments.forEach(function (appointment) { donorIds.add(appointment.donorId); });
  return Array.from(donorIds);
}

function getDonorStatus(donor) {
  if (!donor.lastDonationDate) {
    return 'new';
  }
  return daysSince(donor.lastDonationDate) > inactiveAfterDays ? 'inactive' : 'active';
}

async function buildDonorRows(societyId, donorIds) {
  if (donorIds.length === 0) {
    return [];
  }

  const donors = await User.findAll({
    where: { id: donorIds, accountType: ACCOUNT_TYPES.DONOR },
    order: [['fullName', 'ASC']]
  });

  const interactions = await Interaction.findAll({
    where: { societyId, donorId: donorIds },
    order: [['createdAt', 'DESC']]
  });
  const lastContactByDonor = {};
  interactions.forEach(function (interaction) {
    if (!lastContactByDonor[interaction.donorId]) {
      lastContactByDonor[interaction.donorId] = interaction.createdAt;
    }
  });

  const completedAppointments = await Appointment.findAll({
    where: { donorId: donorIds, status: 'completed' },
    attributes: ['donorId']
  });
  const donationCountByDonor = {};
  completedAppointments.forEach(function (appointment) {
    donationCountByDonor[appointment.donorId] = (donationCountByDonor[appointment.donorId] || 0) + 1;
  });

  return donors.map(function (donor) {
    const eligibility = calculateDonationEligibility(donor.lastDonationDate);
    const lastContactedAt = lastContactByDonor[donor.id] || null;
    const recentlyContacted = lastContactedAt && daysSince(lastContactedAt) < followUpGapInDays;

    return {
      id: donor.id,
      fullName: donor.fullName,
      email: donor.email,
      phoneNumber: donor.phoneNumber,
      bloodGroup: donor.bloodGroup,
      city: donor.city,
      lastDonationDate: donor.lastDonationDate,
      status: getDonorStatus(donor),
      isEligibleToDonate: eligibility.isEligible,
      daysUntilEligible: eligibility.daysRemaining,
      totalDonations: donationCountByDonor[donor.id] || 0,
      lastContactedAt,
      needsFollowUp: eligibility.isEligible && !recentlyContacted
    };
  });
}

async function getCrmSummary(req, res) {
  try {
    const society = await loadSocietyOrReject(req, res);
    if (!society) return;

    const donorIds = await findDonorIdsForSociety(society.id);
    const rows = await buildDonorRows(society.id, donorIds);

    res.json({
      totalDonors: rows.length,
      needFollowUp: rows.filter(function (row) { return row.needsFollowUp; }).length,
      newDonors: rows.filter(function (row) { return row.status === 'new'; }).length,
      activeDonors: rows.filter(function (row) { return row.status === 'active'; }).length,
      inactiveDonors: rows.filter(function (row) { return row.status === 'inactive'; }).length
    });
  } catch (error) {
    res.status(500).json({ error: 'Could not load CRM summary.' });
  }
}

async function listCrmDonors(req, res) {
  try {
    const society = await loadSocietyOrReject(req, res);
    if (!society) return;

    const { status, bloodGroup, city } = req.query;
    const donorIds = await findDonorIdsForSociety(society.id);
    let rows = await buildDonorRows(society.id, donorIds);

    if (status === 'due') {
      rows = rows.filter(function (row) { return row.needsFollowUp; });
    } else if (['new', 'active', 'inactive'].includes(status)) {
      rows = rows.filter(function (row) { return row.status === status; });
    }
    if (bloodGroup) {
      rows = rows.filter(function (row) { return row.bloodGroup === bloodGroup; });
    }
    if (city) {
      const searchedCity = city.trim().toLowerCase();
      rows = rows.filter(function (row) {
        return row.city && row.city.toLowerCase().includes(searchedCity);
      });
    }

    res.json({ donors: rows });
  } catch (error) {
    res.status(500).json({ error: 'Could not load donors.' });
  }
}

async function getCrmDonorProfile(req, res) {
  try {
    const society = await loadSocietyOrReject(req, res);
    if (!society) return;

    const donorId = Number(req.params.id);
    const donorIds = await findDonorIdsForSociety(society.id);
    if (!donorIds.includes(donorId)) {
      return res.status(404).json({ error: 'Donor not found in your CRM.' });
    }

    const [donorRow] = await buildDonorRows(society.id, [donorId]);

    const appointments = await Appointment.findAll({
      where: { donorId, societyId: society.id }
    });
    const emergencyResponses = await EmergencyResponse.findAll({
      where: { donorId },
      include: [{
        model: BloodRequest,
        as: 'bloodRequest',
        where: { requestedBySocietyId: society.id },
        attributes: ['bloodGroup', 'city']
      }]
    });
    const interactions = await Interaction.findAll({
      where: { donorId, societyId: society.id }
    });

    const timeline = [];
    appointments.forEach(function (appointment) {
      timeline.push({
        kind: 'appointment',
        date: appointment.appointmentDate,
        title: 'Appointment ' + appointment.status,
        notes: appointment.notes
      });
    });
    emergencyResponses.forEach(function (response) {
      timeline.push({
        kind: 'emergency',
        date: response.createdAt,
        title: 'Offered help on an emergency request (' + response.bloodRequest.bloodGroup + ', ' + response.bloodRequest.city + ')',
        notes: null
      });
    });
    interactions.forEach(function (interaction) {
      timeline.push({
        kind: interaction.interactionType,
        date: interaction.createdAt,
        title: 'You logged a ' + interaction.interactionType,
        notes: interaction.notes
      });
    });
    timeline.sort(function (first, second) {
      return new Date(second.date) - new Date(first.date);
    });

    res.json({ donor: donorRow, timeline });
  } catch (error) {
    res.status(500).json({ error: 'Could not load donor profile.' });
  }
}

async function logInteraction(req, res) {
  try {
    const society = await loadSocietyOrReject(req, res);
    if (!society) return;

    const { donorId, interactionType, notes } = req.body;

    if (!allowedInteractionTypes.includes(interactionType)) {
      return res.status(400).json({ error: 'Please choose a valid contact type.' });
    }
    const donorIds = await findDonorIdsForSociety(society.id);
    if (!donorIds.includes(Number(donorId))) {
      return res.status(404).json({ error: 'Donor not found in your CRM.' });
    }
    const cleanNotes = notes ? String(notes).trim().slice(0, 500) : null;

    await Interaction.create({
      donorId: Number(donorId),
      societyId: society.id,
      interactionType,
      notes: cleanNotes || null
    });

    res.status(201).json({ message: 'Contact logged.' });
  } catch (error) {
    res.status(500).json({ error: 'Could not log contact.' });
  }
}

module.exports = {
  getCrmSummary,
  listCrmDonors,
  getCrmDonorProfile,
  logInteraction
};
