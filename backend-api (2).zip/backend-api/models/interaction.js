const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Interaction = sequelize.define('Interaction', {
  donorId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  societyId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  interactionType: {
    type: DataTypes.ENUM('call', 'message', 'visit', 'other'),
    allowNull: false,
    defaultValue: 'call'
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'crm_interactions',
  timestamps: true
});

module.exports = Interaction;
