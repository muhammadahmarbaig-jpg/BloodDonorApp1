if (requireAuthOrRedirect()) {
  startCrmPage();
}
renderBackButton();

async function startCrmPage() {
  try {
    const homeData = await apiRequest('/home');
    renderAppBar(homeData.user.accountType);
    if (homeData.user.accountType !== ACCOUNT_TYPES.SOCIETY) {
      window.location.href = 'home.html';
      return;
    }
  } catch (error) {
    clearToken();
    window.location.href = 'login.html';
    return;
  }
  loadSummary();
  loadDonors();
}

function showError(message) {
  const errorBox = document.getElementById('error-message');
  errorBox.textContent = message;
  errorBox.classList.remove('page-hidden');
}

async function loadSummary() {
  try {
    const summary = await apiRequest('/crm/summary');
    document.getElementById('crm-summary').innerHTML =
      '<span class="stat-pill">' + summary.totalDonors + ' total</span>' +
      '<span class="stat-pill stat-pill-waiting">' + summary.needFollowUp + ' need follow-up</span>' +
      '<span class="stat-pill stat-pill-eligible">' + summary.activeDonors + ' active</span>' +
      '<span class="stat-pill stat-pill-pending">' + summary.newDonors + ' new</span>' +
      '<span class="stat-pill">' + summary.inactiveDonors + ' inactive</span>';
  } catch (error) {
    showError(error.message);
  }
}

function formatDate(value) {
  return value ? new Date(value).toLocaleDateString() : 'Never';
}

function statusBadge(status) {
  if (status === 'active') return '<span class="badge-eligible">Active</span>';
  if (status === 'inactive') return '<span class="badge-waiting">Inactive</span>';
  return '<span class="badge-pending">New</span>';
}

async function loadDonors() {
  const filters = new URLSearchParams();
  const status = document.getElementById('filter-status').value;
  const bloodGroup = document.getElementById('filter-blood-group').value;
  const city = document.getElementById('filter-city').value.trim();
  if (status) filters.append('status', status);
  if (bloodGroup) filters.append('bloodGroup', bloodGroup);
  if (city) filters.append('city', city);

  try {
    const data = await apiRequest('/crm/donors?' + filters.toString());
    const tableBody = document.getElementById('crm-donor-rows');
    document.getElementById('no-donors-message').classList.toggle('page-hidden', data.donors.length > 0);

    tableBody.innerHTML = data.donors.map(function (donor) {
      const followUpHtml = donor.needsFollowUp
        ? '<span class="badge-emergency">Contact</span>'
        : '<span class="badge-pending">Not needed</span>';
      return '<tr>' +
        '<td>' + escapeHtml(donor.fullName) + '</td>' +
        '<td>' + escapeHtml(donor.bloodGroup) + '</td>' +
        '<td>' + escapeHtml(donor.city) + '</td>' +
        '<td>' + statusBadge(donor.status) + '</td>' +
        '<td>' + donor.totalDonations + '</td>' +
        '<td>' + formatDate(donor.lastContactedAt) + '</td>' +
        '<td>' + followUpHtml + '</td>' +
        '<td><a class="text-link" href="crm-donor.html?id=' + donor.id + '">View</a></td>' +
        '</tr>';
    }).join('');
  } catch (error) {
    showError(error.message);
  }
}

document.getElementById('crm-filter-form').addEventListener('submit', function (event) {
  event.preventDefault();
  loadDonors();
});
