const donorId = new URLSearchParams(window.location.search).get('id');

if (requireAuthOrRedirect()) {
  startDonorPage();
}
renderBackButton();

async function startDonorPage() {
  try {
    const homeData = await apiRequest('/home');
    renderAppBar(homeData.user.accountType);
    if (homeData.user.accountType !== ACCOUNT_TYPES.SOCIETY) {
      window.location.href = 'home.html';
      return;
    }
  } catch (error) {
    clearToken();
    window.location.href = 'login.html';
    return;
  }
  loadDonorProfile();
}

function showMessage(boxId, message) {
  const box = document.getElementById(boxId);
  box.textContent = message;
  box.classList.remove('page-hidden');
}

function formatDate(value) {
  return value ? new Date(value).toLocaleString() : 'Never';
}

async function loadDonorProfile() {
  try {
    const data = await apiRequest('/crm/donors/' + encodeURIComponent(donorId));
    renderDonor(data.donor);
    renderTimeline(data.timeline);
  } catch (error) {
    showMessage('error-message', error.message);
  }
}

function renderDonor(donor) {
  document.getElementById('donor-name').textContent = donor.fullName;

  const eligibilityPill = donor.isEligibleToDonate
    ? '<span class="stat-pill stat-pill-eligible">Eligible to donate</span>'
    : '<span class="stat-pill stat-pill-waiting">Eligible in ' + donor.daysUntilEligible + ' days</span>';
  document.getElementById('donor-pills').innerHTML =
    eligibilityPill +
    '<span class="stat-pill">' + escapeHtml(donor.status) + '</span>' +
    (donor.needsFollowUp ? '<span class="stat-pill stat-pill-waiting">Needs follow-up</span>' : '');

  document.getElementById('donor-details').innerHTML =
    '<tr><th>Blood Group</th><td>' + escapeHtml(donor.bloodGroup) + '</td></tr>' +
    '<tr><th>City</th><td>' + escapeHtml(donor.city) + '</td></tr>' +
    '<tr><th>Email</th><td>' + escapeHtml(donor.email) + '</td></tr>' +
    '<tr><th>Phone</th><td>' + escapeHtml(donor.phoneNumber || 'Not provided') + '</td></tr>' +
    '<tr><th>Last Donation</th><td>' + (donor.lastDonationDate ? new Date(donor.lastDonationDate).toLocaleDateString() : 'Never') + '</td></tr>' +
    '<tr><th>Total Donations</th><td>' + donor.totalDonations + '</td></tr>' +
    '<tr><th>Last Contacted</th><td>' + formatDate(donor.lastContactedAt) + '</td></tr>';
}

function renderTimeline(timeline) {
  document.getElementById('no-history-message').classList.toggle('page-hidden', timeline.length > 0);
  document.getElementById('donor-timeline').innerHTML = timeline.map(function (entry) {
    const notesHtml = entry.notes ? '<div class="timeline-notes">' + escapeHtml(entry.notes) + '</div>' : '';
    return '<li class="timeline-item">' +
      '<div class="timeline-date">' + formatDate(entry.date) + '</div>' +
      '<div class="timeline-title">' + escapeHtml(entry.title) + '</div>' +
      notesHtml +
      '</li>';
  }).join('');
}

document.getElementById('log-contact-form').addEventListener('submit', async function (event) {
  event.preventDefault();
  document.getElementById('error-message').classList.add('page-hidden');
  document.getElementById('success-message').classList.add('page-hidden');

  try {
    await apiRequest('/crm/interactions', {
      method: 'POST',
      body: {
        donorId: Number(donorId),
        interactionType: document.getElementById('interactionType').value,
        notes: document.getElementById('notes').value
      }
    });
    document.getElementById('notes').value = '';
    showMessage('success-message', 'Contact logged.');
    loadDonorProfile();
  } catch (error) {
    showMessage('error-message', error.message);
  }
});
